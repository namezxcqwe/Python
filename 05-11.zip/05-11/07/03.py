word = str(input())
print(word[-1])