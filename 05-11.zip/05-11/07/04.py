word1 = str(input())
word2 = str(input())
if word1[-1] == word2[0]:
    print('ВЕРНО')
else:
    print('НЕВЕРНО')