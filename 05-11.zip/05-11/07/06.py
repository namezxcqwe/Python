word = str(input())
for i in range(len(word)):
    print(word[i])