word = input()
for letter in word:
    print(ord(letter), end = ', ')