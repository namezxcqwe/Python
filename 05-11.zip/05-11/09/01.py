n = int(input())
list = []
for i in range(n):
    word = input()
    list.append(word)
for word in list:
    print(word)