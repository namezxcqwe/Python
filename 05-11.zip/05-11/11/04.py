print(' '.join([str(int(i) ** 2) for i in input().split()
                if int(i) % 2 != 0and int(i) ** 2 % 10 != 9]))