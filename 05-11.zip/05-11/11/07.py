print('\n'.join(input().split(' ')))
