srt = input()
print(srt[srt.find('q') + 2:srt.find('&')])