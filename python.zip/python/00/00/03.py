call = 'Ауууу!'
print(call)
print(call)