call = 'Ауууууу!'
print(call)
print(call)