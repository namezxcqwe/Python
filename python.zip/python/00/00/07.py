filmname = input('Название фильма: ')
cinema = input('Название кинотеатра: ')
time = input('Время: ')
print("Билет на фильм",  filmname,  "в",  cinema,  "на",  time, "забронирован")