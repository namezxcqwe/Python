word = 'Ayyyy!'
print('Человек:', word)
print('Эхо:', word)