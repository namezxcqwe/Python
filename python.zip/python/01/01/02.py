python = input('Введите слово: ')
if python == 'Python':
    print('ДА')
else:
    print('НЕТ')