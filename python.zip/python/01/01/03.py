number1 = input('Введите первое число: ')
number2 = input('Введите второе число: ')
number3 = input('Введите третье число: ')
if number1 == 'раз' and number2 == 'два' and number3 == 'три':
    print('ГОРИ')
else:
    print('НЕ ГОРИ')