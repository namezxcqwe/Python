number1 = input('Введите первое число: ')
number2 = input('Введите второе число: ')
number3 = input('Введите третье число: ')
if number1 == 'раз' or 'один' and number2 == 'два' and number3 == 'три':
    print('ГОРИ')
elif number1 == '1' and number2 == '2' and number3 == '3':
    print('ГОРИ')
else:
    print('НЕ ГОРИ')