word = input('Введите слово: ')
print(word * 4)