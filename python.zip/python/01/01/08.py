question = input('Ведите свой вопрос: ')
if 'кот' in question:
    print('МЯУ')
else:
    print('ГАВ')