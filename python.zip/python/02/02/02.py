import math
print(math.factorial(9))
