metr = 1400
zemlekop = 6
if metr % zemlekop != 0:
    print(metr // zemlekop + 1)