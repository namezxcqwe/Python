days_per_year = 365
hours_per_day = 24
minutes_per_hour = 60
min = days_per_year * hours_per_day * minutes_per_hour
print(min)