a = float(input('Введите первое число: '))
b = float(input('Введите второе число: '))
print(a + b)