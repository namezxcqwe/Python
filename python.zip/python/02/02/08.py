word = str(input('Введите любое слово : '))
print('<< Слово', word, 'имеет длину', len(word), '>>.')