borya = 130
vova = 110
dima = 120
borya, vova, dima = vova, dima, borya
print(borya)
print(vova)
print(dima)