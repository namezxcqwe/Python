number = float(input('Введите дробное число: '))
if number > 0:
    print('+')
elif number < 0:
    print('-')
else:
    print('0')