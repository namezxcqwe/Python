string = str(input('Введите ваше сообщение: '))
print(len(string) * 40 // 100, 'р.', (len(string) * 40) % 100, 'коп.')