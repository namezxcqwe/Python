t = float(input('Введите температуру: '))
if t < 15.5:
 print('Холодно')
elif t > 28:
 print('Жарко')
else:
 print('Нормально')