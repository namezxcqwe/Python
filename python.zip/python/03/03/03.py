number = int(input('Введите любое число: '))
while number != 0:
    print(number)
    number = int(input('Введите любое число: '))