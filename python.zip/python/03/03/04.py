string = input('Введите любую строку: ')
while len(string) != 0:
    print(string)
    string = input('Введите любую строку: ')
