money = int(input('Money: '))
while money >= 8:
    money //= 8
    print(money)