text = input('Введите ваше изречение: ')
for _ in range(int(input('Введите кол-во повторений: '))):
    print(text)