n = int(input()) + 1
for t in range(n):
    print(f"Куб числа {t} равен {t ** 3}" )