i = 1
for _ in range(6):
    k = int(input('Введите целое число: '))
    if k != 0:
        i *= k
print(i)