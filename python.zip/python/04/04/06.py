n = int(input('Введите любое натуральное число: '))
for i in range(n + 1):
    print(i, end = ' ')
