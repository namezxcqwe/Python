for i in range(17):
    d = int(input('Введите натуральное число: '))
    if i % d == 0:
        print('ДА')
    else:
        print('НЕТ')